import numpy as np
import matplotlib.pyplot as plt
#%matplotlib inline
from IPython import get_ipython
get_ipython().run_line_magic('matplotlib', 'inline')

# Make sure that caffe is on the python path:
caffe_root = '../'  # this file is expected to be in {caffe_root}/examples
import sys
sys.path.insert(0, caffe_root + 'python')

import caffe

#!diff ../exper/voc12/config/VGG16/train_trainval.prototxt ../exper/voc12/config/VGG16/train_trainval_featuremap_redu.prototxt

# Load the original network and extract the fully connected layers' parameters.
net = caffe.Net('../exper/voc12/config/VGG16/train_trainval_featuremap_5_over_16_8_ch.prototxt', 
                '../exper/voc12/config/VGG16/half_featuremap/quarter_8_ch/5_over_16/half_featuremap_iter_5000.caffemodel',
                caffe.TRAIN)

params = ['conv1_1', 'conv1_2', 'conv2_1', 'conv2_2', 'conv3_1', 'conv3_2', 'conv3_3', 'conv4_1', 'conv4_2', 'conv4_3', 'conv5_1', 'conv5_2', 'conv5_3', 'fc6_1', 'fc7_1', 'fc8_voc10_1', 'fc6_2', 'fc7_2', 'fc8_voc10_2', 'fc6_3', 'fc7_3', 'fc8_voc10_3', 'fc6_4', 'fc7_4', 'fc8_voc10_4']
# fc_params = {name: (weights, biases)}
fc_params = {pr: (net.params[pr][0].data, net.params[pr][1].data) for pr in params}

for fc in params:
    print '{} weights are {} dimensional and biases are {} dimensional'.format(fc, fc_params[fc][0].shape, fc_params[fc][1].shape)

# Load the fully convolutional network to transplant the parameters.
net_full_conv = caffe.Net('../exper/voc12/config/VGG16/train_trainval_featuremap_90.prototxt', 
                          '../exper/voc12/model/VGG16/init_90.caffemodel',
                          caffe.TRAIN)
#net_full_conv = caffe.Net('../exper/voc12/config/VGG16/train_trainval_featuremap_redu.prototxt', 
#                          '../exper/voc12/config/VGG16/half_featuremap/half_featuremap_iter_34.caffemodel',
#                          caffe.TRAIN)
params_full_conv = ['conv1_1', 'conv1_2', 'conv2_1', 'conv2_2', 'conv3_1', 'conv3_2', 'conv3_3', 'conv4_1', 'conv4_2', 'conv4_3', 'conv5_1', 'conv5_2', 'conv5_3', 'fc6_1', 'fc7_1', 'fc8_voc10_1', 'fc6_2', 'fc7_2', 'fc8_voc10_2', 'fc6_3', 'fc7_3', 'fc8_voc10_3', 'fc6_4', 'fc7_4', 'fc8_voc10_4']
# conv_params = {name: (weights, biases)}
conv_params = {pr: (net_full_conv.params[pr][0].data, net_full_conv.params[pr][1].data) for pr in params_full_conv}

for conv in params_full_conv:
    print '{} weights are {} dimensional and biases are {} dimensional'.format(conv, conv_params[conv][0].shape, conv_params[conv][1].shape)
    
##for pr, pr_conv in zip(params, params_full_conv):
conv_params['conv1_1'][0][0:32,0:3,0:3,0:3] = fc_params['conv1_1'][0][0:32,0:3,0:3,0:3]
conv_params['conv1_1'][1][0:32] = fc_params['conv1_1'][1][0:32]

conv_params['conv1_2'][0][0:32,0:32,0:3,0:3] = fc_params['conv1_2'][0][0:32,0:32,0:3,0:3]
conv_params['conv1_2'][1][0:32] = fc_params['conv1_2'][1][0:32]

conv_params['conv2_1'][0][0:32,0:32,0:3,0:3] = fc_params['conv2_1'][0][0:32,0:32,0:3,0:3]
conv_params['conv2_1'][1][0:32] = fc_params['conv2_1'][1][0:32]

conv_params['conv2_2'][0][0:32,0:32,0:3,0:3] = fc_params['conv2_2'][0][0:32,0:32,0:3,0:3]
conv_params['conv2_2'][1][0:32] = fc_params['conv2_2'][1][0:32]

conv_params['conv3_1'][0][0:64,0:32,0:3,0:3] = fc_params['conv3_1'][0][0:64,0:32,0:3,0:3]
conv_params['conv3_1'][1][0:64] = fc_params['conv3_1'][1][0:64]

conv_params['conv3_2'][0][0:64,0:64,0:3,0:3] = fc_params['conv3_2'][0][0:64,0:64,0:3,0:3]
conv_params['conv3_2'][1][0:64] = fc_params['conv3_2'][1][0:64]

conv_params['conv3_3'][0][0:64,0:64,0:3,0:3] = fc_params['conv3_3'][0][0:64,0:64,0:3,0:3]
conv_params['conv3_3'][1][0:64] = fc_params['conv3_3'][1][0:64]

conv_params['conv4_1'][0][0:128,0:64,0:3,0:3] = fc_params['conv4_1'][0][0:128,0:64,0:3,0:3]
conv_params['conv4_1'][1][0:128] = fc_params['conv4_1'][1][0:128]

conv_params['conv4_2'][0][0:128,0:128,0:3,0:3] = fc_params['conv4_2'][0][0:128,0:128,0:3,0:3]
conv_params['conv4_2'][1][0:128] = fc_params['conv4_2'][1][0:128]

conv_params['conv4_3'][0][0:128,0:128,0:3,0:3] = fc_params['conv4_3'][0][0:128,0:128,0:3,0:3]
conv_params['conv4_3'][1][0:128] = fc_params['conv4_3'][1][0:128]

conv_params['conv5_1'][0][0:128,0:128,0:3,0:3] = fc_params['conv5_1'][0][0:128,0:128,0:3,0:3]
conv_params['conv5_1'][1][0:128] = fc_params['conv5_1'][1][0:128]

conv_params['conv5_2'][0][0:128,0:128,0:3,0:3] = fc_params['conv5_2'][0][0:128,0:128,0:3,0:3]
conv_params['conv5_2'][1][0:128] = fc_params['conv5_2'][1][0:128]

conv_params['conv5_3'][0][0:128,0:128,0:3,0:3] = fc_params['conv5_3'][0][0:128,0:128,0:3,0:3]
conv_params['conv5_3'][1][0:128] = fc_params['conv5_3'][1][0:128]

conv_params['fc6_1'][0][0:256,0:128,0:3,0:3] = fc_params['fc6_1'][0][0:256,0:128,0:3,0:3]
conv_params['fc6_1'][1][0:256] = fc_params['fc6_1'][1][0:256]

conv_params['fc7_1'][0][0:1024,0:256,0:1,0:1] = fc_params['fc7_1'][0][0:1024,0:256,0:1,0:1]
conv_params['fc7_1'][1][0:1024] = fc_params['fc7_1'][1][0:1024]

conv_params['fc8_voc10_1'][0][0:7,0:1024,0:1,0:1] = fc_params['fc8_voc10_1'][0][0:7,0:1024,0:1,0:1]
conv_params['fc8_voc10_1'][1][0:7] = fc_params['fc8_voc10_1'][1][0:7]

conv_params['fc6_2'][0][0:256,0:128,0:3,0:3] = fc_params['fc6_2'][0][0:256,0:128,0:3,0:3]
conv_params['fc6_2'][1][0:256] = fc_params['fc6_2'][1][0:256]

conv_params['fc7_2'][0][0:1024,0:256,0:1,0:1] = fc_params['fc7_2'][0][0:1024,0:256,0:1,0:1]
conv_params['fc7_2'][1][0:1024] = fc_params['fc7_2'][1][0:1024]

conv_params['fc8_voc10_2'][0][0:7,0:1024,0:1,0:1] = fc_params['fc8_voc10_2'][0][0:7,0:1024,0:1,0:1]
conv_params['fc8_voc10_2'][1][0:7] = fc_params['fc8_voc10_2'][1][0:7]

conv_params['fc6_3'][0][0:256,0:128,0:3,0:3] = fc_params['fc6_3'][0][0:256,0:128,0:3,0:3]
conv_params['fc6_3'][1][0:256] = fc_params['fc6_3'][1][0:256]

conv_params['fc7_3'][0][0:1024,0:256,0:1,0:1] = fc_params['fc7_3'][0][0:1024,0:256,0:1,0:1]
conv_params['fc7_3'][1][0:1024] = fc_params['fc7_3'][1][0:1024]

conv_params['fc8_voc10_3'][0][0:7,0:1024,0:1,0:1] = fc_params['fc8_voc10_3'][0][0:7,0:1024,0:1,0:1]
conv_params['fc8_voc10_3'][1][0:7] = fc_params['fc8_voc10_3'][1][0:7]

conv_params['fc6_4'][0][0:256,0:128,0:3,0:3] = fc_params['fc6_4'][0][0:256,0:128,0:3,0:3]
conv_params['fc6_4'][1][0:256] = fc_params['fc6_4'][1][0:256]

conv_params['fc7_4'][0][0:1024,0:256,0:1,0:1] = fc_params['fc7_4'][0][0:1024,0:256,0:1,0:1]
conv_params['fc7_4'][1][0:1024] = fc_params['fc7_4'][1][0:1024]

conv_params['fc8_voc10_4'][0][0:7,0:1024,0:1,0:1] = fc_params['fc8_voc10_4'][0][0:7,0:1024,0:1,0:1]
conv_params['fc8_voc10_4'][1][0:7] = fc_params['fc8_voc10_4'][1][0:7]



net_full_conv.save('../exper/voc12/model/VGG16/init_quarter_8_ch.caffemodel');