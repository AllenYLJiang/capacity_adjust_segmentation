function set_mode_cpu()
% set_mode_cpu()
%   set Caffe to CPU mode

caffe_('set_mode_cpu');

end
