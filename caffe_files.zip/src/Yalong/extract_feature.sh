#!/usr/bin/env sh
# args for EXTRACT_FEATURE
TOOL=../../build/tools
MODEL=../../exper/voc12/config/VGG16/mediate_result_iter_412.caffemodel #下载得到的caffe model
PROTOTXT=../../examples/_temp/test_test_ucf101.prototxt # 网络定义
LAYER=conv5_1 # 提取层的名字，如提取fc7等
LEVELDB=../../examples/_temp/features_conv1 # 保存的leveldb路径
BATCHSIZE=100

# args for LEVELDB to MAT
DIM=7573504 # 需要手工计算feature长度
OUT=../../examples/_temp/features.mat #.mat文件保存路径
BATCHNUM=1 # 有多少哥batch， 本例只有两张图， 所以只有一个batch

$TOOL/extract_features.bin  $MODEL $PROTOTXT $LAYER $LEVELDB $BATCHSIZE
python leveldb2mat.py $LEVELDB $BATCHNUM $BATCHSIZE $DIM $OUT 
